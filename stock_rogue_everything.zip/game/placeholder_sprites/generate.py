"""Generate simple top-down placeholder sprites, all facing RIGHT (rotation 0)."""
from PIL import Image, ImageDraw

def new(size=64):
    return Image.new("RGBA", (size, size), (0, 0, 0, 0))

# --- Player: rounded body + a clear "barrel" pointing right so aim is obvious ---
def player():
    img = new(64)
    d = ImageDraw.Draw(img)
    # body
    d.ellipse([12, 12, 52, 52], fill=(70, 130, 220, 255), outline=(20, 40, 90, 255), width=3)
    # gun barrel pointing right (the "front")
    d.rectangle([44, 28, 62, 36], fill=(30, 30, 40, 255), outline=(10, 10, 15, 255), width=1)
    # little direction notch on top so facing is unmistakable
    d.polygon([(32, 12), (40, 4), (24, 4)], fill=(200, 220, 255, 255))
    return img

# --- Enemy: angular red body, small spike pointing right ---
def enemy():
    img = new(64)
    d = ImageDraw.Draw(img)
    d.regular_polygon((32, 32, 22), n_sides=6, rotation=0,
                      fill=(200, 60, 60, 255), outline=(90, 15, 15, 255))
    # eye/front marker toward right
    d.ellipse([40, 27, 50, 37], fill=(255, 230, 120, 255), outline=(60, 40, 0, 255), width=2)
    return img

# --- Bullet: small bright pill ---
def bullet():
    img = new(16)
    d = ImageDraw.Draw(img)
    d.ellipse([2, 5, 14, 11], fill=(255, 220, 90, 255), outline=(180, 120, 0, 255), width=1)
    return img

# --- Enemy bullet: red variant ---
def enemy_bullet():
    img = new(16)
    d = ImageDraw.Draw(img)
    d.ellipse([2, 5, 14, 11], fill=(255, 110, 90, 255), outline=(150, 20, 0, 255), width=1)
    return img

player().save("player.png")
enemy().save("enemy.png")
bullet().save("bullet.png")
enemy_bullet().save("enemy_bullet.png")
print("saved: player.png, enemy.png, bullet.png, enemy_bullet.png")
