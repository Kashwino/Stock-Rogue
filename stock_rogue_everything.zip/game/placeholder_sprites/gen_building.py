from PIL import Image, ImageDraw

def floor_tile():
    img = Image.new("RGBA", (64, 64), (0,0,0,0))
    d = ImageDraw.Draw(img)
    d.rectangle([0,0,63,63], fill=(38,40,48,255))
    d.rectangle([0,0,63,63], outline=(52,54,64,255), width=2)
    return img

def wall_tile():
    img = Image.new("RGBA", (64, 64), (0,0,0,0))
    d = ImageDraw.Draw(img)
    d.rectangle([0,0,63,63], fill=(70,72,84,255), outline=(95,97,110,255), width=2)
    # brick lines
    for y in range(16, 64, 16):
        d.line([(0,y),(63,y)], fill=(55,57,66,255), width=1)
    return img

def door_closed():
    img = Image.new("RGBA", (64, 96), (0,0,0,0))
    d = ImageDraw.Draw(img)
    d.rectangle([8,4,56,92], fill=(120,55,50,255), outline=(60,25,22,255), width=3)
    d.ellipse([44,44,52,52], fill=(220,190,90,255))  # handle
    return img

def door_open():
    img = Image.new("RGBA", (64, 96), (0,0,0,0))
    d = ImageDraw.Draw(img)
    d.rectangle([8,4,56,92], fill=(35,60,40,255), outline=(70,150,80,255), width=3)
    # open gap
    d.rectangle([20,10,52,86], fill=(20,22,28,255))
    return img

floor_tile().save("floor_tile.png")
wall_tile().save("wall_tile.png")
door_closed().save("door_closed.png")
door_open().save("door_open.png")
print("saved building sprites")
